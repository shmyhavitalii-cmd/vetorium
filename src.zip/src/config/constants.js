export const CONTRACT_ADDRESS = "J7gr5uPExeRmTc6GdVNyXj4zmYdXmYLYFC5TkkDngm4x";
export const COMMUNITY_LINKS = {
  telegram: "#",
  discord: "#",
  twitter: "#",
  linkedin: "#",
};
export const WHITEPAPER_URL = "/docs/whitepaper-v0.3.pdf"; // placeholder
export const TECHNICAL_PAPER_URL = "/docs/technical-paper.pdf";
export const PRIVATE_SALE_URL = "/docs/private-sale-agreement.pdf";
export const TERM_SHEET_URL = "/docs/term-sheet.pdf";
